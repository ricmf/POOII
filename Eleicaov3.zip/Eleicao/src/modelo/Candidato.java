package modelo;

public class Candidato {
    
    private Partido partido;
    private int numeroCampanha;
    
    
}
